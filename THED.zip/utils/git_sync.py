# 📁 utils/git_sync.py – GitHub auto-sync avec .env

import subprocess
import os
from datetime import datetime
from dotenv import load_dotenv

# Charger les variables depuis le fichier .env
load_dotenv()

def push_to_github():
    """
    Effectue un commit automatique et un push Git
    en utilisant les informations de configuration issues du fichier .env
    """
    # Récupération des variables d'environnement
    branch = os.getenv("GIT_BRANCH", "main")
    auteur = os.getenv("GIT_COMMIT_AUTHOR", "Bot Auto")
    email = os.getenv("GIT_COMMIT_EMAIL", "bot@example.com")
    repo_name = os.getenv("GIT_REPO_NAME", "repo-inconnu")

    try:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        commit_message = f"Auto-sync {timestamp} | {repo_name}"

        # Configuration Git utilisateur (si nécessaire)
        subprocess.run(["git", "config", "user.name", auteur], check=True)
        subprocess.run(["git", "config", "user.email", email], check=True)

        # Étapes Git standard
        subprocess.run(["git", "add", "."], check=True)
        subprocess.run(["git", "commit", "-m", commit_message], check=True)
        subprocess.run(["git", "push", "origin", branch], check=True)

        print(f"✅ Commit et push vers GitHub ({branch}) réussi à {timestamp}")

    except subprocess.CalledProcessError as e:
        print(f"❌ Erreur Git lors du push : {e}")
