
def envoyer_alerte(message):
    print(f"🔔 Alerte : {message}")
