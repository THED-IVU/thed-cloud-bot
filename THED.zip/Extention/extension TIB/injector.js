// injector.js – Injection automatique de popups IA dans Pocket Option

(function () {
  console.log("🧠 Injection IA démarrée dans la page...");

  // ==== Partie 1 : Injection initiale de signaux simulés ====
  const signaux = [
    {
      id: "popup1",
      direction: "HAUT",
      score: 87,
      contexte: "Retournement haussier",
      resume: "EMA 9/21 croisé + RSI > 50",
      fondamental: "Pas de news négative",
      mise: "2 USD",
      duree: "60s"
    },
    {
      id: "popup2",
      direction: "BAS",
      score: 78,
      contexte: "Zone de résistance",
      resume: "Double top + divergence RSI",
      fondamental: "Données neutres",
      mise: "3 USD",
      duree: "120s"
    }
  ];

  function createSimulatedPopup(signal, index) {
    const popup = document.createElement("div");
    popup.classList.add("ia-popup");
    popup.style.position = "fixed";
    popup.style.bottom = `${20 + index * 140}px`;
    popup.style.right = "20px";
    popup.style.width = "300px";
    popup.style.background = "#1c1c1c";
    popup.style.border = "1px solid #444";
    popup.style.borderRadius = "10px";
    popup.style.padding = "10px";
    popup.style.boxShadow = "0 0 12px #00f7ff";
    popup.style.zIndex = "9999";
    popup.style.color = "#fff";
    popup.style.fontFamily = "Segoe UI";

    popup.innerHTML = `
      <h4 style="color:#00f7ff;">📊 Signal IA (${signal.direction})</h4>
      <p><strong>Score :</strong> ${signal.score}%</p>
      <p><strong>Contexte :</strong> ${signal.contexte}</p>
      <p><strong>Résumé :</strong><br><em>${signal.resume}</em></p>
      <p><strong>Fondamental :</strong><br><em>${signal.fondamental}</em></p>
      <p>💰 <strong>Mise :</strong> ${signal.mise} – <strong>Durée :</strong> ${signal.duree}</p>
      <button id="valider_${signal.id}" style="background:#ffa500;color:white;border:none;padding:8px 12px;border-radius:6px;margin-top:8px;cursor:pointer;">
        ✅ Valider manuellement
      </button>
    `;

    document.body.appendChild(popup);

    document.getElementById(`valider_${signal.id}`).addEventListener("click", () => {
      const message = {
        type: "SIGNAL_MANUEL_VALIDÉ",
        payload: signal
      };

      console.log("📤 Signal IA validé :", message);

      try {
        const ws = new WebSocket("ws://localhost:8765");
        ws.onopen = () => {
          ws.send(JSON.stringify(message));
        };
      } catch (e) {
        console.warn("❌ WebSocket non disponible :", e);
      }

      alert(`🚀 Signal ${signal.direction} envoyé avec succès !`);
    });
  }

  signaux.forEach((s, i) => createSimulatedPopup(s, i));

  // ==== Partie 2 : WebSocket + Template externe ====
  (async function () {
    const templateUrl = chrome.runtime.getURL("popup_template.html");
    const templateHTML = await fetch(templateUrl).then(res => res.text());

    const ws = new WebSocket("ws://localhost:8765");

    ws.onopen = () => {
      console.log("✅ WebSocket IA connecté");
    };

    ws.onmessage = (event) => {
      const signal = JSON.parse(event.data);
      if (!signal || !signal.direction) return;

      const id = `popup_${Date.now()}`;

      const wrapper = document.createElement("div");
      wrapper.innerHTML = templateHTML;

      const popup = wrapper.firstElementChild;
      popup.style.position = "fixed";
      popup.style.right = "20px";
      popup.style.bottom = `${Math.random() * 300 + 50}px`;
      popup.style.zIndex = 9999;
      popup.style.boxShadow = "0 0 12px var(--accent)";
      popup.style.border = "1px solid #444";
      popup.id = id;

      // Injection dynamique des données
      popup.querySelector("#dir").innerText = signal.direction || "–";
      popup.querySelector("#score").innerText = signal.score || "–";
      popup.querySelector("#contexte").innerText = signal.contexte || "–";
      popup.querySelector("#resume").innerText = signal.resume || "–";
      popup.querySelector("#fondamental").innerText = signal.fondamental || "–";
      popup.querySelector("#mise").innerText = signal.mise || "–";
      popup.querySelector("#duree").innerText = signal.duree || "–";

      popup.querySelector("#validerBtn").addEventListener("click", () => {
        const confirmPayload = {
          type: "SIGNAL_MANUEL_VALIDÉ",
          payload: signal
        };
        ws.send(JSON.stringify(confirmPayload));
        alert("🚀 Signal IA validé (WebSocket)");
      });

      document.body.appendChild(popup);
    };
  })();
})();
