# report_auto.py - fichier auto-généré pour structure complète
