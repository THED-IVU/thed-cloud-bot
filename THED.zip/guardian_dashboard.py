# guardian_dashboard.py - fichier auto-généré pour structure complète
