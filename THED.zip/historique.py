import streamlit as st
from trading import afficher_historique

st.title("📜 Historique des trades exécutés")

afficher_historique()
