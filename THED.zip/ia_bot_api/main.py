from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from analyseur import analyser_marche

app = FastAPI(title="IA_BOT_API", description="API d'analyse IA pour bot de trading", version="1.0")

class PromptRequest(BaseModel):
    prompt: str

class PromptResponse(BaseModel):
    reponse: str

@app.get("/health")
def check_health():
    return {"status": "OK"}

@app.post("/analyser", response_model=PromptResponse)
def analyser_prompt(request: PromptRequest):
    try:
        resultat = analyser_marche(request.prompt)
        return {"reponse": resultat}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))