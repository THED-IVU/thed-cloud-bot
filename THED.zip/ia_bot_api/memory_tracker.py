# 📁 ia_bot_api/analyseur.py – Analyse IA avec mémoire intégrée

import requests
from memory_tracker import enregistrer_interaction

def analyser_marche(prompt: str) -> str:
    """
    Analyse hybride combinant :
    - Règles codées à la main
    - Appel IA via LLM (Ollama)
    - Journalisation des interactions
    """
    prompt_clean = prompt.lower()

    # --- Règles locales ---
    if "eurusd" in prompt_clean and "m5" in prompt_clean:
        reponse = (
            "[RÈGLE] EURUSD M5 : RSI > 70 → zone de surachat. MACD = croisement baissier. Vente possible."
        )
        enregistrer_interaction(prompt, reponse, source="RÈGLE")
        return reponse

    if "rsi" in prompt_clean and "achat" in prompt_clean:
        reponse = (
            "[RÈGLE] RSI < 30 : zone de survente détectée. Achat à envisager si confirmation."
        )
        enregistrer_interaction(prompt, reponse, source="RÈGLE")
        return reponse

    # --- Appel au modèle LLM via Ollama ---
    try:
        url = "http://localhost:11434/api/generate"
        headers = {"Content-Type": "application/json"}
        data = {
            "model": "mistral",
            "prompt": f"Tu es un expert en trading. Analyse la situation suivante : {prompt}. Donne une décision claire (achat, vente ou attendre) avec justification.",
            "stream": False
        }
        response = requests.post(url, json=data, headers=headers, timeout=15)
        if response.status_code == 200:
            resultat = response.json().get("response", "[LLM] Erreur de réponse IA.")
            enregistrer_interaction(prompt, resultat, source="LLM")
            return f"[LLM] {resultat.strip()}"
        else:
            erreur = f"[LLM] Erreur HTTP : {response.status_code}"
            enregistrer_interaction(prompt, erreur, source="LLM")
            return erreur
    except Exception as e:
        erreur = f"[LLM] Erreur de connexion à l'IA : {str(e)}"
        enregistrer_interaction(prompt, erreur, source="LLM")
        return erreur
