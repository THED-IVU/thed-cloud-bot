
# 📄 pages/4_Apprentissage_IA.py

import streamlit as st
from ia_bot_api.learning_model import entrainer_modele, predire_resultat

st.set_page_config(page_title="Apprentissage IA", layout="wide")
st.title("📚 Entraînement et Prédiction IA")
st.markdown("Apprenez un modèle à partir de la mémoire IA et testez une prédiction simple.")

if st.button("🚀 Entraîner le modèle IA"):
    modele = entrainer_modele()
    if modele:
        st.success("Modèle entraîné avec succès. Essayez une prédiction ci-dessous.")
    else:
        st.error("Échec de l'entraînement (pas assez de données valides).")
else:
    modele = None

st.divider()

st.subheader("🔮 Tester une prédiction hypothétique")
col1, col2, col3 = st.columns(3)
with col1:
    source = st.selectbox("Source IA :", ["LLM", "RÈGLE"])
with col2:
    validation = st.selectbox("Validation IA :", ["valide", "invalide"])
with col3:
    mode_demo = st.radio("Mode de trading :", ["démo", "réel"]) == "démo"

if st.button("🔎 Prédire résultat hypothétique"):
    if not modele:
        modele = entrainer_modele()
    if modele:
        resultat = predire_resultat(modele, source, validation, mode_demo)
        st.success(f"✅ Prédiction : {'GAGNÉ' if resultat else 'PERDU'}")
