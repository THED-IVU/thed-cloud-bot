
# 📄 pages/3_Feedback_IA.py

import streamlit as st
from ia_bot_api.feedback_evaluator import enregistrer_feedback
from ia_bot_api.memory_tracker import charger_interactions
import datetime

st.set_page_config(page_title="Feedback IA", layout="wide")
st.title("📊 Feedback sur les décisions IA")
st.markdown("""Ajoutez un retour (gagné / perdu) sur les décisions IA, en mode **réel** ou **démo**.""")

data = charger_interactions()
prompts_sans_feedback = [item for item in data if "feedback" not in item]

if not prompts_sans_feedback:
    st.success("🎉 Tous les signaux IA ont déjà un retour !")
else:
    options = [f"{i+1} - {item['prompt'][:80]}..." for i, item in enumerate(prompts_sans_feedback)]
    selection = st.selectbox("🧠 Choisissez une analyse à évaluer :", options)

    idx = options.index(selection)
    interaction = prompts_sans_feedback[idx]

    st.markdown(f"**📥 Prompt sélectionné :** {interaction['prompt']}")
    st.markdown(f"**📤 Réponse IA :** {interaction['reponse']}")

    col1, col2 = st.columns(2)
    with col1:
        resultat = st.radio("🎯 Résultat du trade :", ["gagné", "perdu", "neutre"], horizontal=True)
    with col2:
        mode = st.radio("🧪 Mode de trading :", ["démo", "réel"], horizontal=True)

    if st.button("💾 Enregistrer le feedback"):
        enregistrer_feedback(prompt=interaction["prompt"], resultat_trade=resultat, mode=mode)
        st.success("Feedback enregistré avec succès. Recharge la page pour voir la mise à jour.")
