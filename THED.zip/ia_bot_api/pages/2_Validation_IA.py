
# 📄 pages/2_Validation_IA.py

import streamlit as st
import pandas as pd
import json
import os
from datetime import datetime

MEMORY_FILE = "ia_memory.json"
MEMORY_PATH = os.path.join("ia_bot_api", MEMORY_FILE)

st.set_page_config(page_title="Validation IA", layout="wide")
st.title("🧠 Validation des décisions IA")
st.markdown("Visualisez et validez les réponses IA enregistrées.")

# Chargement de la mémoire IA
def charger_donnees():
    if not os.path.exists(MEMORY_PATH):
        return []
    with open(MEMORY_PATH, "r") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []

def sauvegarder_donnees(donnees):
    with open(MEMORY_PATH, "w") as f:
        json.dump(donnees, f, indent=4)

# Interface
donnees = charger_donnees()
filtre_source = st.selectbox("Filtrer par source :", options=["Toutes", "LLM", "RÈGLE"])

if filtre_source != "Toutes":
    donnees = [d for d in donnees if d["source"] == filtre_source]

df = pd.DataFrame(donnees)

if df.empty:
    st.info("Aucune interaction IA disponible.")
else:
    for i, interaction in enumerate(donnees):
        col1, col2, col3 = st.columns([4, 6, 3])
        with col1:
            st.markdown(f"**🕒 {interaction['timestamp']}**")
            st.write(f"**Source :** {interaction['source']}")
            st.write(f"**Prompt :** {interaction['prompt']}")
        with col2:
            st.write(f"**Réponse :** {interaction['reponse']}")
        with col3:
            validation = st.radio(
                f"Validation #{i+1}",
                options=["Aucune", "valide", "invalide"],
                index=["Aucune", "valide", "invalide"].index(interaction["validation"] if interaction["validation"] else "Aucune"),
                key=f"validation_{i}"
            )
            interaction["validation"] = validation if validation != "Aucune" else None

    if st.button("💾 Enregistrer les validations"):
        sauvegarder_donnees(donnees)
        st.success("Validations mises à jour avec succès.")
