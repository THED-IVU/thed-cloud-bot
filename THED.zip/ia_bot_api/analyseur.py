def analyser_marche(prompt: str) -> str:
    prompt = prompt.lower()

    if "eurusd" in prompt and "m5" in prompt:
        return (
            "Analyse professionnelle EURUSD M5 : RSI au-dessus de 70 indique une zone de surachat. "
            "MACD montre un croisement baissier. Probabilité de retournement élevée. Vendre sous confirmation."
        )

    elif "rsi" in prompt and "achat" in prompt:
        return (
            "RSI sous 30 : survente détectée. Acheter possible si confirmation par MACD et chandelier haussier."
        )

    elif "macd" in prompt and "vente" in prompt:
        return (
            "MACD en croisement baissier et histogramme négatif. Si volume soutenu, vente probable."
        )

    else:
        return (
            "Je suis un analyste IA : merci de préciser l'actif, l'unité de temps et au moins un indicateur comme RSI, MACD ou Bollinger."
        )