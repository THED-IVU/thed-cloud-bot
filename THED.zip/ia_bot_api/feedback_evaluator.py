
# 📁 ia_bot_api/feedback_evaluator.py

import json
import os
from datetime import datetime

MEMORY_FILE = "ia_memory.json"
MEMORY_PATH = os.path.join("ia_bot_api", MEMORY_FILE)

def charger_interactions():
    if not os.path.exists(MEMORY_PATH):
        return []
    with open(MEMORY_PATH, "r") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []

def sauvegarder_interactions(data):
    with open(MEMORY_PATH, "w") as f:
        json.dump(data, f, indent=4)

def enregistrer_feedback(prompt: str, resultat_trade: str, mode: str = "démo"):
    '''
    Enregistre un retour (feedback) sur la qualité d'une décision IA
    :param prompt: le prompt d'origine
    :param resultat_trade: "gagné", "perdu" ou "neutre"
    :param mode: "démo" ou "réel"
    '''
    data = charger_interactions()
    updated = False

    for item in reversed(data):
        if item["prompt"] == prompt and "feedback" not in item:
            item["feedback"] = {
                "resultat_trade": resultat_trade,
                "mode": mode,
                "horodatage": datetime.now().isoformat()
            }
            updated = True
            break

    if updated:
        sauvegarder_interactions(data)
        print("✔️ Feedback enregistré avec succès.")
    else:
        print("⚠️ Aucun prompt correspondant trouvé ou feedback déjà existant.")
