
# 📁 ia_bot_api/learning_model.py

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import json
import os

MEMORY_PATH = os.path.join("ia_bot_api", "ia_memory.json")
MODEL_PATH = os.path.join("ia_bot_api", "model_rf.pkl")

def charger_donnees_entrainement():
    if not os.path.exists(MEMORY_PATH):
        return pd.DataFrame()

    with open(MEMORY_PATH, "r") as f:
        data = json.load(f)

    rows = []
    for d in data:
        if "feedback" in d and d["feedback"].get("resultat_trade") in ["gagné", "perdu"]:
            rows.append({
                "source": 1 if d["source"] == "LLM" else 0,
                "valide": 1 if d["validation"] == "valide" else 0,
                "mode_demo": 1 if d["feedback"]["mode"] == "démo" else 0,
                "résultat": 1 if d["feedback"]["resultat_trade"] == "gagné" else 0
            })

    return pd.DataFrame(rows)

def entrainer_modele():
    df = charger_donnees_entrainement()
    if df.empty:
        print("Pas assez de données pour entraîner le modèle.")
        return None

    X = df.drop("résultat", axis=1)
    y = df["résultat"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    score = model.score(X_test, y_test)
    print(f"✔️ Modèle entraîné avec une précision de : {score:.2%}")
    return model

def predire_resultat(model, source, valide, mode_demo):
    X = pd.DataFrame([{
        "source": 1 if source == "LLM" else 0,
        "valide": 1 if valide == "valide" else 0,
        "mode_demo": 1 if mode_demo else 0
    }])
    return model.predict(X)[0]
