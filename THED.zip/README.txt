Structure d'insertion des fichiers :
- pages/6_PocketOption_Copilote_FINAL.py → Interface IA principale
- pages/popup_modal_ia.html → Popup dynamique IA (à la racine de pages/)
- core/pocket_executor.py → Envoi ou simulation de trade Pocket Option
- core/learning_tracker.py → Apprentissage IA par journalisation
- core/export_csv.py → Export automatique des résultats dans un CSV
- scripts/lancer_bot_secure.bat → Lancement automatisé Streamlit + Ngrok
- websocket/ → Serveur WebSocket et client pour commandes à distance
- notif/telegram_alert.py → Notifications Telegram (nécessite token)
