# 1_Dashboard_d_mobile.py - fichier auto-généré pour structure complète
