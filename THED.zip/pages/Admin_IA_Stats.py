# Admin_IA_Stats.py - fichier auto-généré pour structure complète
