# Admin_IA_Config.py - fichier auto-généré pour structure complète
