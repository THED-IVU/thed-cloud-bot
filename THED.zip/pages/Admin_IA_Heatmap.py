# Admin_IA_Heatmap.py - fichier auto-généré pour structure complète
