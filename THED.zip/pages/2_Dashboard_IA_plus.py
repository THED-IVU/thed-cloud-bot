# 2_Dashboard_IA_plus.py - fichier auto-généré pour structure complète
