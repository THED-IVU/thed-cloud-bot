# Admin_IA_Contextes.py - fichier auto-généré pour structure complète
