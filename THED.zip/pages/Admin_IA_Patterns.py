# Admin_IA_Patterns.py - fichier auto-généré pour structure complète
