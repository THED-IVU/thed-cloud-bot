# Dashboard_IA_Resultats.py - fichier auto-généré pour structure complète
