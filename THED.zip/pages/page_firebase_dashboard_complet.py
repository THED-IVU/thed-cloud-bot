# page_firebase_dashboard_complet.py - fichier auto-généré pour structure complète
