# pages/14_Tester_Alerte_IA.py

import streamlit as st
from datetime import datetime
from notifications.ia_alerts import envoyer_alerte_ia

st.set_page_config(page_title="📢 Test Alerte IA", layout="centered")
st.title("📢 Test Manuel des Alertes IA")

st.info("Ce module permet de tester l'envoi manuel d'une alerte IA stratégique par **Telegram** ou **Email**.")

# Exemple de données simulées
example_data = {
    "horodatage": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    "source": "ia_locale",
    "marche": "forex",
    "horizon": "1j",
    "niveau": "professionnel",
    "analyse_technique": "🧮 Croisement EMA + RSI > 60 détecté.",
    "analyse_fondamentale": "📈 L'USD est soutenu par de solides chiffres macro.",
    "contexte_macro": "💬 Taux FED attendu en hausse",
    "risques": "⚠️ Volatilité liée à la guerre commerciale US/Chine",
    "recommandation": "✅ Achat sur USD/JPY à court terme.",
    "prediction": "Probabilité de hausse estimée à 78%",
    "score_confiance": 87
}

st.json(example_data)

if st.button("🚀 Envoyer l’alerte IA maintenant"):
    try:
        envoyer_alerte_ia(example_data)
        st.success("✅ Alerte IA envoyée avec succès !")
    except Exception as e:
        st.error(f"❌ Échec de l'envoi : {e}")
