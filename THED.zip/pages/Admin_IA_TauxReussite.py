# Admin_IA_TauxReussite.py - fichier auto-généré pour structure complète
