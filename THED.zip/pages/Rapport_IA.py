# Rapport_IA.py - fichier auto-généré pour structure complète
