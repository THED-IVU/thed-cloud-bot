# telegram_bot.py - fichier auto-généré pour structure complète
