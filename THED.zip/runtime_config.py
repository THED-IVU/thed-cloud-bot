def get_runtime_config():
    return {
        "use_ai": True,
        "default_model": "gpt-4",
        "max_tokens": 200
    }
