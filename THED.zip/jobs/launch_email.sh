#!/bin/bash

cd /chemin/vers/BOT_MT5_THED_PRO/jobs
python3 email_cron.py
