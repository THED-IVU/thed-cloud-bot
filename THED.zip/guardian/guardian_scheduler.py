# ✅ guardian_scheduler.py – Superviseur intelligent unifié

import sys
import os
import time
import signal
import subprocess
import datetime
import json
import streamlit as st
import schedule

# === Ajout dynamique des chemins ===
current_dir = os.path.dirname(__file__)
root_dir = os.path.abspath(os.path.join(current_dir, ".."))
notifications_dir = os.path.join(root_dir, "notifications")
core_dir = os.path.join(root_dir, "core")
utils_dir = os.path.join(root_dir, "utils")

sys.path.extend([root_dir, notifications_dir, core_dir, utils_dir])

# === Modules internes Guardian ===
from utils.path_utils import ajouter_base_et_sous_dossiers
ajouter_base_et_sous_dossiers()
from guardian_scanner import scanner_complet
from guardian_suggestions import generer_suggestions
from guardian_executor import executer_correctifs
from guardian_reporter import enregistrer_rapport_json, enregistrer_rapport_pdf
from telegram_alert import envoyer_alerte_guardian
from email_cron import generer_contenu_html_guardian, envoyer_email_rapport

# 🔁 Firebase + GitHub + IA
from core.firebase_sync import push_ia_decision_to_firebase
from ia_strategique import analyser_contexte
from ia_storage import sauvegarder_resultat
from git_sync import push_to_github

# === CONFIGURATION ===
INTERVAL_HEURES = 6
INTERVAL_SECONDES = INTERVAL_HEURES * 3600
PROCESS_KEY = "guardian_pid"

# === STREAMLIT INTERFACE ===
st.set_page_config(page_title="🛡️ Planificateur Guardian Fusionné", layout="centered")
st.title("🛡️ Guardian IA – Planificateur & Supervision")
st.markdown("Cette interface permet de **surveiller automatiquement le bot**, d'**analyser le marché**, d'**appliquer des correctifs IA** et de **synchroniser Firebase & GitHub** toutes les 6h.")

if PROCESS_KEY not in st.session_state:
    st.session_state[PROCESS_KEY] = None

# === TÂCHE COMPLÈTE FUSIONNÉE ===
def tache_complete():
    horodatage = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"\n[{horodatage}] 🧠 Lancement de la tâche Guardian complète...")

    try:
        # 🔍 1. Scanner Guardian
        rapport = scanner_complet(".")
        suggestions = generer_suggestions(rapport)
        correctifs = [s for s in suggestions if s.get("impact", 100) >= 50]

        if correctifs:
            resultats = executer_correctifs(correctifs)
            fichier = f"auto_guardian_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
            enregistrer_rapport_json(resultats, fichier)
            enregistrer_rapport_pdf(resultats, fichier)

            envoyer_alerte_guardian(resultats)
            contenu = generer_contenu_html_guardian(resultats)
            envoyer_email_rapport("📊 Rapport Auto – Guardian IA", contenu)

            print(f"[{horodatage}] ✅ Correctifs appliqués et alertes envoyées.")
        else:
            print(f"[{horodatage}] ✅ Aucun correctif requis.")

    except Exception as e:
        print(f"[{horodatage}] ❌ Erreur dans le module Guardian : {e}")

    try:
        # 📊 2. Analyse stratégique IA
        print(f"[{horodatage}] 🧠 Analyse IA stratégique...")
        resultat = analyser_contexte(marche="forex", horizon="1j", niveau="professionnel", source="auto")
        sauvegarder_resultat(resultat, source="auto")
        push_ia_decision_to_firebase("forex_global", resultat)
        print(f"[{horodatage}] ✅ Analyse IA sauvegardée.")
    except Exception as e:
        print(f"[{horodatage}] ❌ Erreur dans l’analyse IA : {e}")

    try:
        # ☁️ 3. Firebase sync
        print(f"[{horodatage}] ☁️ Synchronisation Firebase...")
        print(f"[{horodatage}] ✅ Firebase activé via core/firebase_sync.py")
    except Exception as e:
        print(f"[{horodatage}] ❌ Erreur Firebase : {e}")

    try:
        # 🌐 4. Push GitHub
        print(f"[{horodatage}] 📤 Push GitHub...")
        push_to_github()
        print(f"[{horodatage}] ✅ Code mis à jour sur GitHub.")
    except Exception as e:
        print(f"[{horodatage}] ❌ Erreur GitHub : {e}")

    print(f"[{horodatage}] 💤 Prochaine exécution dans {INTERVAL_HEURES}h...\n")

# 🔁 Scheduler basé sur `schedule`
schedule.every(INTERVAL_HEURES).hours.do(tache_complete)

# === BOUCLE D'EXÉCUTION POUR MODE CONSOLE ===
def boucle_guardian_complete():
    print(f"🧠 Planificateur IA Guardian lancé – Toutes les {INTERVAL_HEURES} heures.")
    while True:
        schedule.run_pending()
        time.sleep(60)

# === STREAMLIT – Contrôle utilisateur ===
col1, col2, col3 = st.columns(3)

with col1:
    if st.button("▶️ Lancer Guardian Fusionné"):
        if st.session_state[PROCESS_KEY] is None:
            process = subprocess.Popen(["python", "guardian_scheduler.py"], start_new_session=True)
            st.session_state[PROCESS_KEY] = process.pid
            st.success(f"✅ Guardian lancé (PID: {process.pid})")
        else:
            st.warning("⚠️ Un processus Guardian est déjà en cours.")

with col2:
    if st.button("⛔ Arrêter Guardian"):
        pid = st.session_state[PROCESS_KEY]
        if pid:
            try:
                os.kill(pid, signal.SIGTERM)
                st.success(f"🛑 Guardian arrêté (PID: {pid})")
                st.session_state[PROCESS_KEY] = None
            except Exception as e:
                st.error(f"❌ Erreur lors de l'arrêt : {e}")
        else:
            st.info("Aucun processus actif à arrêter.")

with col3:
    if st.button("🧪 Tester maintenant"):
        st.warning("⏳ Exécution manuelle en cours…")
        tache_complete()
        st.success("✅ Exécution manuelle terminée.")

# === CLI MODE ===
if __name__ == "__main__":
    boucle_guardian_complete()
