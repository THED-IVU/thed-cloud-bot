import os
import json
from datetime import datetime

# Dossiers à ignorer
DOSSIERS_EXCLUS = ["__pycache__", ".venv", ".git", "venv", "env"]

# 📁 Dossier des logs
LOG_PATH = "guardian_logs/scanner_report.log"
os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)

def smart_diagnostics():
    print("🧠 Analyse IA lancée pour les anomalies détectées... (placeholder)")
    # À compléter si souhaité : appel IA locale ou GPT

def scanner_complet(racine=".", extensions=[".py"], export_json=True):
    rapport = []
    anomalies = False

    for root, dirs, files in os.walk(racine):
        # 🔒 Exclure certains dossiers
        dirs[:] = [d for d in dirs if d not in DOSSIERS_EXCLUS]

        for file in files:
            if any(file.endswith(ext) for ext in extensions):
                chemin = os.path.join(root, file)
                try:
                    with open(chemin, "r", encoding="utf-8") as f:
                        contenu = f.read()
                        status = "ok"

                        if "def " not in contenu and "class " not in contenu:
                            status = "vide"
                        elif "TODO" in contenu or "FIXME" in contenu:
                            status = "à corriger"
                            anomalies = True
                except Exception as e:
                    status = f"erreur: {e}"
                    anomalies = True

                rapport.append({
                    "fichier": chemin.replace("\\", "/"),
                    "status": status
                })

    # 📁 Export JSON si demandé
    if export_json:
        export_path = "guardian_logs/dernier_scan.json"
        with open(export_path, "w", encoding="utf-8") as f:
            json.dump(rapport, f, indent=2, ensure_ascii=False)

    # 📝 Journalisation
    with open(LOG_PATH, "a", encoding="utf-8") as logf:
        logf.write(f"\n[{datetime.now().isoformat()}] 🔍 Scan exécuté – {len(rapport)} fichiers\n")
        for ligne in rapport:
            logf.write(f"{ligne['fichier']} => {ligne['status']}\n")

    # 🧠 Analyse IA si anomalie détectée
    if anomalies:
        smart_diagnostics()

    return rapport
