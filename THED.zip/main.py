# 📄 main.py – Point d'entrée pour l'app IA multipage avec Flask Sync

import os
import json
from datetime import datetime
from flask import Flask, request, jsonify
import threading

# === 1. 🧠 Fonction Flask pour recevoir les logs du Guardian ===
app = Flask(__name__)

@app.route('/sync', methods=['POST'])
def sync_logs():
    data = request.form.get("logs")
    os.makedirs("logs", exist_ok=True)
    with open("logs/guardian_synced.log", "a", encoding="utf-8") as f:
        f.write(data + "\n")
    return jsonify({"status": "received"}), 200

def run_flask():
    app.run(host='0.0.0.0', port=5000)

# Lancer Flask dans un thread parallèle pour ne pas bloquer Streamlit
threading.Thread(target=run_flask, daemon=True).start()

# === 2. 🧠 Lancer l'app principale Streamlit ===

# 🔁 Logger une action d'exemple sur Render (peut être modifié)
from core.firebase_logger import envoyer_log_firebase
envoyer_log_firebase(
    plateforme="MT5",
    action="Backtest terminé",
    resultat="gagné",
    strategie="EMA_RSI"
)

# ✅ DOIT ÊTRE LA PREMIÈRE COMMANDE
import streamlit as st
st.set_page_config(page_title="Bot IA Multipage", layout="wide")

# ✅ Import config dynamique IA
from config_state import sidebar_config, get_runtime_config

# ✅ Interface & sidebar dynamique
st.title("🤖 Exécution Automatique")
sidebar_config()
CONFIG = get_runtime_config()

# ✅ Message d'accueil
st.write("Utilise le menu latéral pour naviguer entre les pages.")

# ✅ Affichage IA ou fallback
if CONFIG["use_ai"]:
    modele = CONFIG[CONFIG["ai_provider"]].get("model", "modèle inconnu")
    st.success(f"🧠 IA activée avec : **{CONFIG['ai_provider'].upper()}**\n\nModèle : `{modele}`")
else:
    st.info("⚙️ Mode TECHNIQUE uniquement (IA désactivée)")
