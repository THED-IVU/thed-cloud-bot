# ia_patterns.py - fichier auto-généré pour structure complète
