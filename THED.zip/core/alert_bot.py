
def envoyer_alerte(message):
    print(f"[🔔 ALERTE GUARDIAN] {message}")
