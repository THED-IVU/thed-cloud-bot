# ia_contextes.py - fichier auto-généré pour structure complète
