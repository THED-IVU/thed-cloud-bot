# export_stats.py - fichier auto-généré pour structure complète
