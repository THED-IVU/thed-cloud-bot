# ia_fondamentaux.py - fichier auto-généré pour structure complète
