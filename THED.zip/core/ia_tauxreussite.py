# ia_tauxreussite.py - fichier auto-généré pour structure complète
