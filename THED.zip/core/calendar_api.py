def get_upcoming_events():
    return [
        {"event": "NFP", "time": "14:30", "impact": "High"},
        {"event": "FOMC", "time": "20:00", "impact": "High"},
    ]