# core/config_secure.py
FIREBASE_SECRET = "ta_clé_secrète_ici"
