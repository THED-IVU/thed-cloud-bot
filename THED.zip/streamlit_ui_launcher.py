# streamlit_ui_launcher.py - fichier auto-généré pour structure complète
